<template>
    <div>
        <p>Error message goes here</p>
        <svg aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M6 18L18 6M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>