<template class="">
    <div class="flex justify-center flex-col items-center leading-9 h-full">
        <img src="@/assets/logo.png" class="w-36 pt-20" alt="">
        <h1 class="text-9xl">InoDIP</h1>
        <h1 class="text-4xl">is</h1>
        <h1 class="text-8xl">Coming Soon</h1>
        <p class="pt-20 text-xl">Sorry! This site is under maintanance. It will be live in 1 day</p>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>