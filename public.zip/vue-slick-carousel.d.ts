declare module 'vue-slick-carousel' {
    const VueSlickCarousel: any;
    export default VueSlickCarousel;
  }
  